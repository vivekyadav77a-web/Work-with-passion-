-- MR Employment Platform: initial Supabase schema draft
-- Apply only after creating a Supabase project and reviewing security policies.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  role text not null check (role in ('job_seeker','employer','admin')),
  full_name text not null,
  city text,
  skills text,
  interests text,
  created_at timestamptz not null default now()
);

create table if not exists public.jobs (
  id uuid primary key default gen_random_uuid(),
  employer_id uuid not null references public.profiles(id) on delete cascade,
  title text not null,
  description text not null,
  work_type text not null check (work_type in ('online','offline','both')),
  category text,
  city text,
  pay_details text,
  status text not null default 'pending' check (status in ('pending','approved','rejected','closed')),
  created_at timestamptz not null default now()
);

create table if not exists public.applications (
  id uuid primary key default gen_random_uuid(),
  job_id uuid not null references public.jobs(id) on delete cascade,
  applicant_id uuid not null references public.profiles(id) on delete cascade,
  message text,
  status text not null default 'submitted' check (status in ('submitted','reviewing','shortlisted','rejected','hired')),
  created_at timestamptz not null default now(),
  unique(job_id, applicant_id)
);

alter table public.profiles enable row level security;
alter table public.jobs enable row level security;
alter table public.applications enable row level security;

-- These are deliberately restrictive starter policies, not a complete production policy set.
create policy "profiles read own" on public.profiles for select to authenticated using (auth.uid() = id);
create policy "profiles insert own" on public.profiles for insert to authenticated with check (auth.uid() = id and role <> 'admin');
create policy "profiles update own" on public.profiles for update to authenticated using (auth.uid() = id) with check (auth.uid() = id and role <> 'admin');

create policy "approved jobs public read" on public.jobs for select using (status = 'approved' or employer_id = auth.uid());
create policy "employers create pending jobs" on public.jobs for insert to authenticated with check (employer_id = auth.uid() and status = 'pending');
create policy "employers update own pending jobs" on public.jobs for update to authenticated using (employer_id = auth.uid() and status = 'pending') with check (employer_id = auth.uid() and status = 'pending');

create policy "applicants read own applications" on public.applications for select to authenticated using (applicant_id = auth.uid());
create policy "applicants submit own applications" on public.applications for insert to authenticated with check (applicant_id = auth.uid());

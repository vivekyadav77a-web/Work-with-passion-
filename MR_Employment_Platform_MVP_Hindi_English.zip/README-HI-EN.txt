MR — Dream • Skill • Job | MVP Starter (Hindi + English)

WHAT WORKS IN THIS PACKAGE
- Responsive bilingual Hindi/English interface with language toggle.
- Search and filter the sample job cards.
- Candidate application form stores demo entries in this browser's localStorage.
- Employer job form stores pending demo posts in this browser's localStorage.
- Local demo admin screen can approve/delete local demo posts.
- PWA manifest and service worker for installable Android web app.

IMPORTANT LIMITATIONS
This is a LOCAL DEMO, not a live multi-user employment service.
- localStorage data stays in the same browser/device and is not shared with other users.
- Demo sample jobs are not real vacancies.
- Local demo approval is not real employer verification.
- There is no real login, shared database, secure admin authentication, messaging, notifications or payment.
- Do not enter sensitive personal data or real applicants' details in this demo.

ANDROID / GITHUB PAGES
1. Download and extract the ZIP on Android.
2. In GitHub create a Public repository named `mr-employment-platform`.
3. Upload the CONTENTS of this extracted folder (not the ZIP itself) to the repository root.
4. Open Settings > Pages.
5. Choose Deploy from a branch, branch `main`, folder `/(root)`, then Save.
6. Wait for the HTTPS Pages URL. Open it in Chrome > menu > Install app / Add to Home screen.

NEXT STEP FOR A REAL MULTI-USER SERVICE
1. Create a Supabase project under an eligible account.
2. Review and apply `supabase-schema-draft.sql` in Supabase SQL Editor.
3. Add authentication and strict role-based policies; create the first admin securely.
4. Connect the frontend to Supabase using project URL and publishable/anon key (never expose service_role key).
5. Test employer verification, applications, data deletion, privacy notice, terms and grievance handling.
6. Get legal/privacy review before public launch.

The SQL file is a draft schema and restrictive starter policies, not a complete production-ready security configuration.
